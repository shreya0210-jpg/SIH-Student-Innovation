import { AIWasteScanner } from "@/components/scanner/ai-waste-scanner"

export default function ScannerPage() {
  return <AIWasteScanner />
}
