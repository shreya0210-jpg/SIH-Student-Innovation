import { RewardsWallet } from "@/components/rewards/rewards-wallet"

export default function RewardsPage() {
  return <RewardsWallet />
}
