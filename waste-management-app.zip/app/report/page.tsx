import { ReportSystem } from "@/components/reporting/report-system"

export default function ReportPage() {
  return <ReportSystem />
}
