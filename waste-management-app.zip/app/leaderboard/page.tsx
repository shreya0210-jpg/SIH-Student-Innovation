import { CommunityLeaderboard } from "@/components/leaderboard/community-leaderboard"

export default function LeaderboardPage() {
  return <CommunityLeaderboard />
}
