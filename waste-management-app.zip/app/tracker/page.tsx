import { WasteTracker } from "@/components/tracker/waste-tracker"

export default function TrackerPage() {
  return <WasteTracker />
}
