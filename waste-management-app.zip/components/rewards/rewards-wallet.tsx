"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { X, Wallet, Gift, Bus, ShoppingBag, Coffee, Leaf, Clock, CheckCircle, Star } from "lucide-react"

interface Reward {
  id: string
  title: string
  description: string
  points: number
  category: "transport" | "food" | "shopping" | "eco"
  icon: React.ReactNode
  discount?: string
  validUntil?: string
  partnerId: string
  partnerName: string
  partnerLogo?: string
  terms: string[]
}

interface RedemptionHistory {
  id: string
  rewardTitle: string
  points: number
  redeemedAt: string
  status: "active" | "used" | "expired"
  code?: string
}

const availableRewards: Reward[] = [
  {
    id: "1",
    title: "Free Bus Ride",
    description: "One free ride on city public transport",
    points: 100,
    category: "transport",
    icon: <Bus className="w-5 h-5" />,
    validUntil: "30 days",
    partnerId: "city-transport",
    partnerName: "City Transport",
    terms: ["Valid for single journey", "Cannot be combined with other offers", "Valid on all routes"],
  },
  {
    id: "2",
    title: "Coffee Shop Discount",
    description: "20% off at Green Bean Cafe",
    points: 150,
    category: "food",
    icon: <Coffee className="w-5 h-5" />,
    discount: "20% OFF",
    validUntil: "14 days",
    partnerId: "green-bean",
    partnerName: "Green Bean Cafe",
    terms: ["Valid on all menu items", "One use per customer", "Cannot be combined"],
  },
  {
    id: "3",
    title: "Eco Store Voucher",
    description: "₹200 off on sustainable products",
    points: 300,
    category: "shopping",
    icon: <ShoppingBag className="w-5 h-5" />,
    discount: "₹200 OFF",
    validUntil: "60 days",
    partnerId: "eco-store",
    partnerName: "EcoMart",
    terms: ["Minimum purchase ₹500", "Valid on eco-friendly products only", "One time use"],
  },
  {
    id: "4",
    title: "Plant a Tree",
    description: "Plant a tree in your name",
    points: 200,
    category: "eco",
    icon: <Leaf className="w-5 h-5" />,
    validUntil: "Always available",
    partnerId: "green-earth",
    partnerName: "Green Earth Foundation",
    terms: ["Tree planted in local area", "Certificate provided", "GPS location shared"],
  },
  {
    id: "5",
    title: "Metro Day Pass",
    description: "Unlimited metro rides for one day",
    points: 250,
    category: "transport",
    icon: <Bus className="w-5 h-5" />,
    validUntil: "30 days",
    partnerId: "metro",
    partnerName: "Metro Rail",
    terms: ["Valid for 24 hours from activation", "All lines included", "Non-transferable"],
  },
  {
    id: "6",
    title: "Organic Food Discount",
    description: "15% off at Fresh Organic Market",
    points: 180,
    category: "food",
    icon: <Leaf className="w-5 h-5" />,
    discount: "15% OFF",
    validUntil: "21 days",
    partnerId: "organic-market",
    partnerName: "Fresh Organic",
    terms: ["Valid on organic products", "Maximum discount ₹300", "Valid at all outlets"],
  },
]

const redemptionHistory: RedemptionHistory[] = [
  {
    id: "1",
    rewardTitle: "Free Bus Ride",
    points: 100,
    redeemedAt: "2024-01-15",
    status: "used",
    code: "BUS123456",
  },
  {
    id: "2",
    rewardTitle: "Coffee Shop Discount",
    points: 150,
    redeemedAt: "2024-01-10",
    status: "active",
    code: "COFFEE789",
  },
  {
    id: "3",
    rewardTitle: "Plant a Tree",
    points: 200,
    redeemedAt: "2024-01-05",
    status: "active",
    code: "TREE001",
  },
]

function RewardCard({
  reward,
  userPoints,
  onRedeem,
}: { reward: Reward; userPoints: number; onRedeem: (reward: Reward) => void }) {
  const canRedeem = userPoints >= reward.points

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "transport":
        return "bg-blue-100 text-blue-800"
      case "food":
        return "bg-orange-100 text-orange-800"
      case "shopping":
        return "bg-purple-100 text-purple-800"
      case "eco":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <Card className={`${canRedeem ? "border-primary/30" : "opacity-60"}`}>
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          <div
            className={`w-10 h-10 rounded-full flex items-center justify-center ${canRedeem ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground"}`}
          >
            {reward.icon}
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <Badge className={`text-xs ${getCategoryColor(reward.category)}`}>{reward.category}</Badge>
              {reward.discount && (
                <Badge variant="secondary" className="text-xs bg-accent text-accent-foreground">
                  {reward.discount}
                </Badge>
              )}
            </div>
            <h4 className="font-semibold text-sm mb-1">{reward.title}</h4>
            <p className="text-xs text-muted-foreground mb-2">{reward.description}</p>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-sm font-bold text-primary">{reward.points} points</span>
                <span className="text-xs text-muted-foreground">• {reward.partnerName}</span>
              </div>
              <Dialog>
                <DialogTrigger asChild>
                  <Button size="sm" disabled={!canRedeem} className="text-xs">
                    {canRedeem ? "Redeem" : "Need more points"}
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle className="flex items-center gap-2">
                      {reward.icon}
                      {reward.title}
                    </DialogTitle>
                    <DialogDescription>Redeem this reward for {reward.points} points</DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-semibold mb-2">Description</h4>
                      <p className="text-sm text-muted-foreground">{reward.description}</p>
                    </div>
                    <div>
                      <h4 className="font-semibold mb-2">Terms & Conditions</h4>
                      <ul className="space-y-1">
                        {reward.terms.map((term, index) => (
                          <li key={index} className="text-xs text-muted-foreground flex items-start gap-2">
                            <span className="text-primary mt-1">•</span>
                            {term}
                          </li>
                        ))}
                      </ul>
                    </div>
                    <div className="flex items-center justify-between pt-4 border-t">
                      <div>
                        <p className="text-sm font-medium">Cost: {reward.points} points</p>
                        <p className="text-xs text-muted-foreground">Valid for {reward.validUntil}</p>
                      </div>
                      <Button onClick={() => onRedeem(reward)} disabled={!canRedeem}>
                        Confirm Redemption
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

function HistoryItem({ item }: { item: RedemptionHistory }) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-100 text-green-800"
      case "used":
        return "bg-gray-100 text-gray-800"
      case "expired":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "active":
        return <Clock className="w-4 h-4" />
      case "used":
        return <CheckCircle className="w-4 h-4" />
      case "expired":
        return <X className="w-4 h-4" />
      default:
        return <Clock className="w-4 h-4" />
    }
  }

  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
            <Gift className="w-4 h-4 text-primary" />
          </div>
          <div className="flex-1">
            <h4 className="font-semibold text-sm">{item.rewardTitle}</h4>
            <p className="text-xs text-muted-foreground">
              Redeemed on {new Date(item.redeemedAt).toLocaleDateString()}
            </p>
            {item.code && (
              <p className="text-xs font-mono bg-muted px-2 py-1 rounded mt-1 inline-block">Code: {item.code}</p>
            )}
          </div>
          <div className="text-right">
            <Badge className={`text-xs ${getStatusColor(item.status)} mb-1`}>
              <span className="flex items-center gap-1">
                {getStatusIcon(item.status)}
                {item.status}
              </span>
            </Badge>
            <p className="text-xs text-muted-foreground">-{item.points} pts</p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

export function RewardsWallet() {
  const [activeTab, setActiveTab] = useState("available")
  const [userPoints] = useState(1240) // This would come from user data
  const [selectedCategory, setSelectedCategory] = useState<string>("all")

  const handleRedeem = (reward: Reward) => {
    // Handle redemption logic
    console.log("Redeeming reward:", reward)
    // This would typically update user points and add to history
  }

  const filteredRewards =
    selectedCategory === "all"
      ? availableRewards
      : availableRewards.filter((reward) => reward.category === selectedCategory)

  const categories = [
    { id: "all", label: "All", icon: <Star className="w-4 h-4" /> },
    { id: "transport", label: "Transport", icon: <Bus className="w-4 h-4" /> },
    { id: "food", label: "Food", icon: <Coffee className="w-4 h-4" /> },
    { id: "shopping", label: "Shopping", icon: <ShoppingBag className="w-4 h-4" /> },
    { id: "eco", label: "Eco", icon: <Leaf className="w-4 h-4" /> },
  ]

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border p-4">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="sm" onClick={() => window.history.back()}>
            <X className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="font-bold text-lg text-primary">Rewards Wallet</h1>
            <p className="text-xs text-muted-foreground">Redeem your eco-points</p>
          </div>
        </div>
      </header>

      {/* Points Balance */}
      <section className="p-4">
        <Card className="bg-gradient-to-r from-primary/10 to-accent/10 border-primary/20">
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center">
                <Wallet className="w-8 h-8 text-primary" />
              </div>
              <div className="flex-1">
                <h2 className="text-3xl font-bold text-primary">{userPoints.toLocaleString()}</h2>
                <p className="text-sm text-muted-foreground">Available Eco-Points</p>
                <div className="flex items-center gap-4 mt-2">
                  <span className="text-xs text-muted-foreground">Earned this month: +340</span>
                  <span className="text-xs text-muted-foreground">Redeemed: -200</span>
                </div>
              </div>
              <Badge className="bg-accent text-accent-foreground">Eco Champion</Badge>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Tabs */}
      <section className="p-4">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2 mb-6">
            <TabsTrigger value="available">Available Rewards</TabsTrigger>
            <TabsTrigger value="history">Redemption History</TabsTrigger>
          </TabsList>

          <TabsContent value="available" className="space-y-4">
            {/* Category Filter */}
            <div className="flex gap-2 overflow-x-auto pb-2">
              {categories.map((category) => (
                <Button
                  key={category.id}
                  variant={selectedCategory === category.id ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedCategory(category.id)}
                  className="flex items-center gap-2 whitespace-nowrap"
                >
                  {category.icon}
                  {category.label}
                </Button>
              ))}
            </div>

            {/* Rewards Grid */}
            <div className="space-y-3">
              {filteredRewards.map((reward) => (
                <RewardCard key={reward.id} reward={reward} userPoints={userPoints} onRedeem={handleRedeem} />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="history" className="space-y-3">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-lg text-foreground">Recent Redemptions</h3>
              <Badge variant="outline" className="text-xs">
                Last 30 days
              </Badge>
            </div>
            {redemptionHistory.map((item) => (
              <HistoryItem key={item.id} item={item} />
            ))}
          </TabsContent>
        </Tabs>
      </section>

      {/* Quick Stats */}
      <section className="p-4">
        <h3 className="font-semibold text-lg mb-4 text-foreground">Your Impact</h3>
        <div className="grid grid-cols-3 gap-3">
          <Card>
            <CardContent className="p-3 text-center">
              <Gift className="w-6 h-6 mx-auto mb-1 text-primary" />
              <div className="text-lg font-bold text-primary">12</div>
              <div className="text-xs text-muted-foreground">Rewards Earned</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-3 text-center">
              <Leaf className="w-6 h-6 mx-auto mb-1 text-accent" />
              <div className="text-lg font-bold text-primary">3</div>
              <div className="text-xs text-muted-foreground">Trees Planted</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-3 text-center">
              <Bus className="w-6 h-6 mx-auto mb-1 text-secondary" />
              <div className="text-lg font-bold text-primary">8</div>
              <div className="text-xs text-muted-foreground">Free Rides</div>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  )
}
