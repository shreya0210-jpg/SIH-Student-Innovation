"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { X, TrendingDown, Leaf, Recycle, BarChart3, Target, Lightbulb } from "lucide-react"
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
} from "recharts"

const monthlyData = [
  { month: "Jan", waste: 12, cityAvg: 18, recycled: 8, composted: 3 },
  { month: "Feb", waste: 10, cityAvg: 17, recycled: 7, composted: 2 },
  { month: "Mar", waste: 8, cityAvg: 16, recycled: 6, composted: 2 },
  { month: "Apr", waste: 9, cityAvg: 15, recycled: 7, composted: 3 },
  { month: "May", waste: 7, cityAvg: 14, recycled: 5, composted: 2 },
  { month: "Jun", waste: 6, cityAvg: 13, recycled: 4, composted: 2 },
]

const wasteBreakdown = [
  { name: "Recyclable", value: 45, color: "#15803d" },
  { name: "Biodegradable", value: 30, color: "#84cc16" },
  { name: "General Waste", value: 20, color: "#6b7280" },
  { name: "Hazardous", value: 5, color: "#d97706" },
]

const impactMetrics = [
  {
    title: "CO₂ Saved",
    value: "12kg",
    change: "+2kg",
    trend: "up",
    icon: <Leaf className="w-5 h-5" />,
    description: "vs last month",
  },
  {
    title: "Water Saved",
    value: "450L",
    change: "+50L",
    trend: "up",
    icon: <TrendingDown className="w-5 h-5" />,
    description: "through recycling",
  },
  {
    title: "Waste Reduced",
    value: "6kg",
    change: "-1kg",
    trend: "down",
    icon: <Recycle className="w-5 h-5" />,
    description: "this month",
  },
  {
    title: "Recycling Rate",
    value: "75%",
    change: "+5%",
    trend: "up",
    icon: <Target className="w-5 h-5" />,
    description: "accuracy",
  },
]

const tips = [
  {
    category: "Reduce",
    title: "Use reusable bags",
    description: "Replace plastic bags with cloth or jute bags",
    impact: "Save 10kg plastic/year",
    difficulty: "Easy",
  },
  {
    category: "Reuse",
    title: "Repurpose glass jars",
    description: "Use for storage instead of buying containers",
    impact: "Reduce 5kg waste/month",
    difficulty: "Easy",
  },
  {
    category: "Recycle",
    title: "Separate electronics",
    description: "Take old devices to e-waste centers",
    impact: "Prevent toxic pollution",
    difficulty: "Medium",
  },
  {
    category: "Compost",
    title: "Start home composting",
    description: "Turn kitchen scraps into fertilizer",
    impact: "Reduce 8kg waste/month",
    difficulty: "Medium",
  },
]

function MetricCard({ metric }: { metric: (typeof impactMetrics)[0] }) {
  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center text-primary">
            {metric.icon}
          </div>
          <div className="flex-1">
            <div className="text-2xl font-bold text-foreground">{metric.value}</div>
            <div className="text-xs text-muted-foreground">{metric.title}</div>
          </div>
          <div className="text-right">
            <div className={`text-sm font-medium ${metric.trend === "up" ? "text-green-600" : "text-red-600"}`}>
              {metric.change}
            </div>
            <div className="text-xs text-muted-foreground">{metric.description}</div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

function TipCard({ tip }: { tip: (typeof tips)[0] }) {
  const getCategoryColor = (category: string) => {
    switch (category) {
      case "Reduce":
        return "bg-red-100 text-red-800"
      case "Reuse":
        return "bg-blue-100 text-blue-800"
      case "Recycle":
        return "bg-green-100 text-green-800"
      case "Compost":
        return "bg-amber-100 text-amber-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          <div className="w-8 h-8 bg-accent/10 rounded-full flex items-center justify-center">
            <Lightbulb className="w-4 h-4 text-accent" />
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <Badge className={`text-xs ${getCategoryColor(tip.category)}`}>{tip.category}</Badge>
              <Badge variant="outline" className="text-xs">
                {tip.difficulty}
              </Badge>
            </div>
            <h4 className="font-semibold text-sm mb-1">{tip.title}</h4>
            <p className="text-xs text-muted-foreground mb-2">{tip.description}</p>
            <p className="text-xs font-medium text-primary">{tip.impact}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

export function WasteTracker() {
  const [activeTab, setActiveTab] = useState("overview")

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border p-4">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="sm" onClick={() => window.history.back()}>
            <X className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="font-bold text-lg text-primary">Waste Tracker</h1>
            <p className="text-xs text-muted-foreground">Track your environmental impact</p>
          </div>
        </div>
      </header>

      {/* Impact Metrics */}
      <section className="p-4">
        <h3 className="font-semibold text-lg mb-4 text-foreground">Your Impact This Month</h3>
        <div className="grid grid-cols-2 gap-3">
          {impactMetrics.map((metric, index) => (
            <MetricCard key={index} metric={metric} />
          ))}
        </div>
      </section>

      {/* Tabs */}
      <section className="p-4">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3 mb-6">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="trends">Trends</TabsTrigger>
            <TabsTrigger value="tips">Tips</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {/* Monthly Comparison */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <BarChart3 className="w-4 h-4" />
                  Monthly Waste vs City Average
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={200}>
                  <BarChart data={monthlyData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="waste" fill="#15803d" name="Your Waste (kg)" />
                    <Bar dataKey="cityAvg" fill="#d1d5db" name="City Average (kg)" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Waste Breakdown */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Waste Category Breakdown</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-center mb-4">
                  <ResponsiveContainer width="100%" height={200}>
                    <PieChart>
                      <Pie data={wasteBreakdown} cx="50%" cy="50%" innerRadius={40} outerRadius={80} dataKey="value">
                        {wasteBreakdown.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  {wasteBreakdown.map((item, index) => (
                    <div key={index} className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                      <span className="text-xs text-muted-foreground">
                        {item.name}: {item.value}%
                      </span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Goals Progress */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Target className="w-4 h-4" />
                  Monthly Goals
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span>Reduce waste by 20%</span>
                    <span className="text-primary font-medium">75%</span>
                  </div>
                  <Progress value={75} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span>Recycle 80% of waste</span>
                    <span className="text-primary font-medium">85%</span>
                  </div>
                  <Progress value={85} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span>Scan 50 items</span>
                    <span className="text-primary font-medium">94%</span>
                  </div>
                  <Progress value={94} className="h-2" />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="trends" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">6-Month Waste Trend</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                  <LineChart data={monthlyData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Line type="monotone" dataKey="waste" stroke="#15803d" strokeWidth={3} name="Your Waste (kg)" />
                    <Line
                      type="monotone"
                      dataKey="cityAvg"
                      stroke="#d1d5db"
                      strokeWidth={2}
                      strokeDasharray="5 5"
                      name="City Average (kg)"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Recycling & Composting Trends</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={200}>
                  <BarChart data={monthlyData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="recycled" fill="#84cc16" name="Recycled (kg)" />
                    <Bar dataKey="composted" fill="#15803d" name="Composted (kg)" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="tips" className="space-y-4">
            <div className="text-center mb-6">
              <h3 className="font-semibold text-lg mb-2">Reduce Your Footprint</h3>
              <p className="text-sm text-muted-foreground">Follow the 4 R's: Reduce, Reuse, Recycle, and Compost</p>
            </div>
            {tips.map((tip, index) => (
              <TipCard key={index} tip={tip} />
            ))}
          </TabsContent>
        </Tabs>
      </section>
    </div>
  )
}
