"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Trophy, Medal, Award, Crown, Users, TrendingUp, X, MapPin } from "lucide-react"

interface LeaderboardEntry {
  id: string
  name: string
  points: number
  rank: number
  change: number // +1, -1, 0 for rank change
  avatar?: string
  badge?: string
  isCurrentUser?: boolean
}

interface CommunityEntry {
  id: string
  name: string
  points: number
  rank: number
  members: number
  change: number
  badge?: string
  location: string
}

const communityData: CommunityEntry[] = [
  {
    id: "1",
    name: "Green Colony",
    points: 4200,
    rank: 1,
    members: 156,
    change: 0,
    badge: "Cleanest Area of the Month",
    location: "Sector 15",
  },
  {
    id: "2",
    name: "Shanti Nagar",
    points: 3900,
    rank: 2,
    members: 142,
    change: 1,
    location: "Block A",
  },
  {
    id: "3",
    name: "Eco Heights",
    points: 3750,
    rank: 3,
    members: 98,
    change: -1,
    location: "Phase 2",
  },
  {
    id: "4",
    name: "Garden View",
    points: 3200,
    rank: 4,
    members: 87,
    change: 2,
    location: "Zone C",
  },
  {
    id: "5",
    name: "Palm Residency",
    points: 2950,
    rank: 5,
    members: 76,
    change: -1,
    location: "Sector 8",
  },
]

const individualData: LeaderboardEntry[] = [
  {
    id: "1",
    name: "Priya Sharma",
    points: 1250,
    rank: 1,
    change: 0,
    badge: "Eco Champion",
  },
  {
    id: "2",
    name: "Raj Patel",
    points: 1180,
    rank: 2,
    change: 1,
  },
  {
    id: "3",
    name: "Alex Johnson",
    points: 1120,
    rank: 3,
    change: 0,
    isCurrentUser: true,
  },
  {
    id: "4",
    name: "Maya Singh",
    points: 1050,
    rank: 4,
    change: -2,
  },
  {
    id: "5",
    name: "David Chen",
    points: 980,
    rank: 5,
    change: 1,
  },
]

function RankIcon({ rank }: { rank: number }) {
  if (rank === 1) return <Crown className="w-5 h-5 text-yellow-500" />
  if (rank === 2) return <Medal className="w-5 h-5 text-gray-400" />
  if (rank === 3) return <Award className="w-5 h-5 text-amber-600" />
  return (
    <span className="w-5 h-5 flex items-center justify-center text-sm font-bold text-muted-foreground">#{rank}</span>
  )
}

function ChangeIndicator({ change }: { change: number }) {
  if (change > 0) return <TrendingUp className="w-4 h-4 text-green-500" />
  if (change < 0) return <TrendingUp className="w-4 h-4 text-red-500 rotate-180" />
  return <div className="w-4 h-4 bg-muted-foreground/20 rounded-full" />
}

function CommunityLeaderboardItem({ entry }: { entry: CommunityEntry }) {
  return (
    <Card className={`${entry.rank <= 3 ? "border-primary/30 bg-primary/5" : ""}`}>
      <CardContent className="p-4">
        <div className="flex items-center gap-3">
          <RankIcon rank={entry.rank} />
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
              <h3 className="font-semibold text-foreground">{entry.name}</h3>
              {entry.badge && (
                <Badge variant="secondary" className="text-xs bg-accent text-accent-foreground">
                  {entry.badge}
                </Badge>
              )}
            </div>
            <div className="flex items-center gap-4 text-sm text-muted-foreground">
              <span className="flex items-center gap-1">
                <MapPin className="w-3 h-3" />
                {entry.location}
              </span>
              <span className="flex items-center gap-1">
                <Users className="w-3 h-3" />
                {entry.members} members
              </span>
            </div>
          </div>
          <div className="text-right">
            <div className="font-bold text-lg text-primary">{entry.points.toLocaleString()}</div>
            <div className="text-xs text-muted-foreground">points</div>
          </div>
          <ChangeIndicator change={entry.change} />
        </div>
      </CardContent>
    </Card>
  )
}

function IndividualLeaderboardItem({ entry }: { entry: LeaderboardEntry }) {
  return (
    <Card
      className={`${entry.isCurrentUser ? "border-accent bg-accent/5" : entry.rank <= 3 ? "border-primary/30 bg-primary/5" : ""}`}
    >
      <CardContent className="p-4">
        <div className="flex items-center gap-3">
          <RankIcon rank={entry.rank} />
          <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
            <span className="text-sm font-semibold text-primary">
              {entry.name
                .split(" ")
                .map((n) => n[0])
                .join("")}
            </span>
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
              <h3 className={`font-semibold ${entry.isCurrentUser ? "text-accent" : "text-foreground"}`}>
                {entry.name} {entry.isCurrentUser && "(You)"}
              </h3>
              {entry.badge && (
                <Badge variant="secondary" className="text-xs bg-accent text-accent-foreground">
                  {entry.badge}
                </Badge>
              )}
            </div>
          </div>
          <div className="text-right">
            <div className={`font-bold text-lg ${entry.isCurrentUser ? "text-accent" : "text-primary"}`}>
              {entry.points.toLocaleString()}
            </div>
            <div className="text-xs text-muted-foreground">points</div>
          </div>
          <ChangeIndicator change={entry.change} />
        </div>
      </CardContent>
    </Card>
  )
}

export function CommunityLeaderboard() {
  const [activeTab, setActiveTab] = useState("communities")

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border p-4">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="sm" onClick={() => window.history.back()}>
            <X className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="font-bold text-lg text-primary">Leaderboard</h1>
            <p className="text-xs text-muted-foreground">Community rankings</p>
          </div>
        </div>
      </header>

      {/* Stats Overview */}
      <section className="p-4">
        <div className="grid grid-cols-3 gap-3 mb-6">
          <Card>
            <CardContent className="p-3 text-center">
              <Trophy className="w-6 h-6 mx-auto mb-1 text-accent" />
              <div className="text-lg font-bold text-primary">3rd</div>
              <div className="text-xs text-muted-foreground">Your Rank</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-3 text-center">
              <TrendingUp className="w-6 h-6 mx-auto mb-1 text-green-500" />
              <div className="text-lg font-bold text-primary">+2</div>
              <div className="text-xs text-muted-foreground">This Week</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-3 text-center">
              <Users className="w-6 h-6 mx-auto mb-1 text-secondary" />
              <div className="text-lg font-bold text-primary">1,120</div>
              <div className="text-xs text-muted-foreground">Your Points</div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Leaderboard Tabs */}
      <section className="p-4">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2 mb-6">
            <TabsTrigger value="communities">Communities</TabsTrigger>
            <TabsTrigger value="individuals">Individuals</TabsTrigger>
          </TabsList>

          <TabsContent value="communities" className="space-y-3">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-lg text-foreground">Top Communities</h3>
              <Badge variant="outline" className="text-xs">
                This Month
              </Badge>
            </div>
            {communityData.map((entry) => (
              <CommunityLeaderboardItem key={entry.id} entry={entry} />
            ))}
          </TabsContent>

          <TabsContent value="individuals" className="space-y-3">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-lg text-foreground">Top Contributors</h3>
              <Badge variant="outline" className="text-xs">
                This Month
              </Badge>
            </div>
            {individualData.map((entry) => (
              <IndividualLeaderboardItem key={entry.id} entry={entry} />
            ))}
          </TabsContent>
        </Tabs>
      </section>

      {/* Achievements Section */}
      <section className="p-4">
        <h3 className="font-semibold text-lg mb-4 text-foreground">Recent Achievements</h3>
        <div className="space-y-3">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-accent/10 rounded-full flex items-center justify-center">
                  <Trophy className="w-5 h-5 text-accent" />
                </div>
                <div className="flex-1">
                  <p className="font-medium text-sm">Green Colony wins "Cleanest Area"!</p>
                  <p className="text-xs text-muted-foreground">Achieved 95% proper waste sorting</p>
                </div>
                <Badge className="bg-accent text-accent-foreground text-xs">New</Badge>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                  <Medal className="w-5 h-5 text-primary" />
                </div>
                <div className="flex-1">
                  <p className="font-medium text-sm">Priya Sharma reaches 1000+ points!</p>
                  <p className="text-xs text-muted-foreground">First to achieve Eco Champion status</p>
                </div>
                <Badge variant="outline" className="text-xs">
                  2 days ago
                </Badge>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  )
}
