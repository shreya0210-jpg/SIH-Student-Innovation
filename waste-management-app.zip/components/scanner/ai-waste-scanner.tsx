"use client"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Camera, X, Volume2, RotateCcw, Zap, CheckCircle } from "lucide-react"

interface ScanResult {
  item: string
  category: "recyclable" | "biodegradable" | "hazardous" | "general"
  bin: string
  binColor: string
  confidence: number
  points: number
  tips: string[]
}

const mockScanResults: ScanResult[] = [
  {
    item: "Plastic Water Bottle",
    category: "recyclable",
    bin: "Blue Bin",
    binColor: "blue",
    confidence: 94,
    points: 10,
    tips: ["Remove cap and label", "Rinse before recycling", "Crush to save space"],
  },
  {
    item: "Apple Core",
    category: "biodegradable",
    bin: "Green Bin",
    binColor: "green",
    confidence: 98,
    points: 5,
    tips: ["Perfect for composting", "Will decompose in 2-4 weeks", "Great for soil nutrients"],
  },
  {
    item: "Battery",
    category: "hazardous",
    bin: "Special Collection",
    binColor: "red",
    confidence: 99,
    points: 20,
    tips: ["Never throw in regular trash", "Take to electronics store", "Contains toxic materials"],
  },
  {
    item: "Food Wrapper",
    category: "general",
    bin: "Gray Bin",
    binColor: "gray",
    confidence: 87,
    points: 2,
    tips: ["Cannot be recycled", "Consider reusable alternatives", "Minimize packaging waste"],
  },
]

export function AIWasteScanner() {
  const [isScanning, setIsScanning] = useState(false)
  const [scanResult, setScanResult] = useState<ScanResult | null>(null)
  const [isProcessing, setIsProcessing] = useState(false)
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null)
  const videoRef = useRef<HTMLVideoElement>(null)

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment" }, // Use back camera on mobile
      })
      setCameraStream(stream)
      if (videoRef.current) {
        videoRef.current.srcObject = stream
      }
      setIsScanning(true)
    } catch (error) {
      console.error("Error accessing camera:", error)
      // Fallback for demo purposes
      setIsScanning(true)
    }
  }

  const stopCamera = () => {
    if (cameraStream) {
      cameraStream.getTracks().forEach((track) => track.stop())
      setCameraStream(null)
    }
    setIsScanning(false)
    setScanResult(null)
  }

  const performScan = () => {
    setIsProcessing(true)
    // Simulate AI processing
    setTimeout(() => {
      const randomResult = mockScanResults[Math.floor(Math.random() * mockScanResults.length)]
      setScanResult(randomResult)
      setIsProcessing(false)

      // Simulate voice guidance
      if ("speechSynthesis" in window) {
        const utterance = new SpeechSynthesisUtterance(`${randomResult.item} detected. Throw in ${randomResult.bin}.`)
        utterance.rate = 0.8
        speechSynthesis.speak(utterance)
      }
    }, 2000)
  }

  const resetScan = () => {
    setScanResult(null)
  }

  useEffect(() => {
    return () => {
      if (cameraStream) {
        cameraStream.getTracks().forEach((track) => track.stop())
      }
    }
  }, [cameraStream])

  const getBinColorClass = (color: string) => {
    switch (color) {
      case "blue":
        return "bg-blue-500 text-white"
      case "green":
        return "bg-green-500 text-white"
      case "red":
        return "bg-red-500 text-white"
      case "gray":
        return "bg-gray-500 text-white"
      default:
        return "bg-primary text-primary-foreground"
    }
  }

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "recyclable":
        return "♻️"
      case "biodegradable":
        return "🌱"
      case "hazardous":
        return "⚠️"
      case "general":
        return "🗑️"
      default:
        return "📦"
    }
  }

  if (!isScanning) {
    return (
      <div className="min-h-screen bg-background flex flex-col">
        {/* Header */}
        <header className="bg-card border-b border-border p-4">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm" onClick={() => window.history.back()}>
              <X className="w-4 h-4" />
            </Button>
            <div>
              <h1 className="font-bold text-lg text-primary">AI Waste Scanner</h1>
              <p className="text-xs text-muted-foreground">Point camera at waste item</p>
            </div>
          </div>
        </header>

        {/* Welcome Screen */}
        <div className="flex-1 flex flex-col items-center justify-center p-6 text-center">
          <div className="w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center mb-6">
            <Camera className="w-12 h-12 text-primary" />
          </div>
          <h2 className="text-2xl font-bold mb-2 text-foreground">Smart Waste Detection</h2>
          <p className="text-muted-foreground mb-8 max-w-sm">
            Use AI to identify waste items and get instant sorting guidance with voice instructions.
          </p>

          <div className="grid grid-cols-2 gap-4 mb-8 w-full max-w-sm">
            <Card>
              <CardContent className="p-3 text-center">
                <div className="text-lg mb-1">♻️</div>
                <div className="text-xs text-muted-foreground">Recyclables</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-3 text-center">
                <div className="text-lg mb-1">🌱</div>
                <div className="text-xs text-muted-foreground">Biodegradable</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-3 text-center">
                <div className="text-lg mb-1">⚠️</div>
                <div className="text-xs text-muted-foreground">Hazardous</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-3 text-center">
                <div className="text-lg mb-1">🗑️</div>
                <div className="text-xs text-muted-foreground">General Waste</div>
              </CardContent>
            </Card>
          </div>

          <Button onClick={startCamera} size="lg" className="w-full max-w-sm">
            <Camera className="w-5 h-5 mr-2" />
            Start Scanning
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-black flex flex-col">
      {/* Camera View */}
      <div className="flex-1 relative">
        <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover" />

        {/* Camera Overlay */}
        <div className="absolute inset-0 flex flex-col">
          {/* Top Controls */}
          <div className="flex justify-between items-center p-4">
            <Button variant="ghost" size="sm" onClick={stopCamera} className="text-white bg-black/50">
              <X className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="sm" className="text-white bg-black/50">
              <Volume2 className="w-4 h-4" />
            </Button>
          </div>

          {/* Scanning Frame */}
          <div className="flex-1 flex items-center justify-center p-8">
            <div className="relative w-64 h-64 border-2 border-white rounded-lg">
              <div className="absolute top-0 left-0 w-8 h-8 border-t-4 border-l-4 border-accent rounded-tl-lg"></div>
              <div className="absolute top-0 right-0 w-8 h-8 border-t-4 border-r-4 border-accent rounded-tr-lg"></div>
              <div className="absolute bottom-0 left-0 w-8 h-8 border-b-4 border-l-4 border-accent rounded-bl-lg"></div>
              <div className="absolute bottom-0 right-0 w-8 h-8 border-b-4 border-r-4 border-accent rounded-br-lg"></div>

              {isProcessing && (
                <div className="absolute inset-0 flex items-center justify-center bg-black/50 rounded-lg">
                  <div className="text-white text-center">
                    <Zap className="w-8 h-8 mx-auto mb-2 animate-pulse text-accent" />
                    <p className="text-sm">Analyzing...</p>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Instructions */}
          <div className="p-4 text-center">
            <p className="text-white text-sm mb-4">
              {isProcessing ? "AI is analyzing the item..." : "Position waste item in the frame"}
            </p>
          </div>

          {/* Scan Button */}
          <div className="p-6">
            <Button
              onClick={performScan}
              disabled={isProcessing}
              size="lg"
              className="w-full bg-accent hover:bg-accent/90 text-accent-foreground"
            >
              {isProcessing ? (
                <>
                  <Zap className="w-5 h-5 mr-2 animate-pulse" />
                  Scanning...
                </>
              ) : (
                <>
                  <Camera className="w-5 h-5 mr-2" />
                  Scan Item
                </>
              )}
            </Button>
          </div>
        </div>
      </div>

      {/* Scan Result Modal */}
      {scanResult && (
        <div className="absolute inset-0 bg-black/80 flex items-end">
          <Card className="w-full m-4 mb-6">
            <CardContent className="p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="text-2xl">{getCategoryIcon(scanResult.category)}</div>
                <div className="flex-1">
                  <h3 className="font-bold text-lg">{scanResult.item}</h3>
                  <p className="text-sm text-muted-foreground">{scanResult.confidence}% confidence</p>
                </div>
                <CheckCircle className="w-6 h-6 text-green-500" />
              </div>

              <div className="mb-4">
                <Badge className={`${getBinColorClass(scanResult.binColor)} text-sm px-3 py-1`}>{scanResult.bin}</Badge>
              </div>

              <div className="mb-4">
                <h4 className="font-semibold mb-2">Disposal Tips:</h4>
                <ul className="space-y-1">
                  {scanResult.tips.map((tip, index) => (
                    <li key={index} className="text-sm text-muted-foreground flex items-start gap-2">
                      <span className="text-accent mt-1">•</span>
                      {tip}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="flex items-center justify-between mb-4">
                <span className="text-sm text-muted-foreground">Points earned:</span>
                <Badge variant="secondary" className="bg-accent text-accent-foreground">
                  +{scanResult.points} points
                </Badge>
              </div>

              <div className="flex gap-3">
                <Button onClick={resetScan} variant="outline" className="flex-1 bg-transparent">
                  <RotateCcw className="w-4 h-4 mr-2" />
                  Scan Again
                </Button>
                <Button onClick={stopCamera} className="flex-1">
                  Done
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
