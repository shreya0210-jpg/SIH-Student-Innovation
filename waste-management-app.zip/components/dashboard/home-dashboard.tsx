"use client"

import type React from "react"
import { useRouter } from "next/navigation"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Camera, Trophy, BarChart3, MapPin, Wallet, Leaf, User, Bell } from "lucide-react"

interface QuickActionProps {
  icon: React.ReactNode
  title: string
  subtitle: string
  onClick: () => void
  variant?: "default" | "primary"
}

function QuickAction({ icon, title, subtitle, onClick, variant = "default" }: QuickActionProps) {
  return (
    <Card
      className={`cursor-pointer transition-all hover:scale-105 hover:shadow-md ${
        variant === "primary" ? "bg-primary text-primary-foreground" : "bg-card"
      }`}
      onClick={onClick}
    >
      <CardContent className="p-4 text-center space-y-2">
        <div
          className={`mx-auto w-12 h-12 rounded-full flex items-center justify-center ${
            variant === "primary" ? "bg-primary-foreground/20" : "bg-primary/10"
          }`}
        >
          {icon}
        </div>
        <div>
          <h3 className="font-semibold text-sm">{title}</h3>
          <p className={`text-xs ${variant === "primary" ? "text-primary-foreground/80" : "text-muted-foreground"}`}>
            {subtitle}
          </p>
        </div>
      </CardContent>
    </Card>
  )
}

export function HomeDashboard() {
  const router = useRouter()
  const userName = "Alex" // This would come from auth context
  const co2Saved = 12 // This would come from user data

  const quickActions = [
    {
      icon: <Camera className="w-6 h-6" />,
      title: "Scan Waste",
      subtitle: "AI-powered sorting",
      onClick: () => router.push("/scanner"),
      variant: "primary" as const,
    },
    {
      icon: <Trophy className="w-6 h-6 text-accent" />,
      title: "Leaderboard",
      subtitle: "Community rankings",
      onClick: () => router.push("/leaderboard"),
    },
    {
      icon: <BarChart3 className="w-6 h-6 text-primary" />,
      title: "My Waste Tracker",
      subtitle: "Track your impact",
      onClick: () => router.push("/tracker"),
    },
    {
      icon: <MapPin className="w-6 h-6 text-secondary" />,
      title: "Report Dirty Spots",
      subtitle: "Help clean community",
      onClick: () => router.push("/report"),
    },
    {
      icon: <Wallet className="w-6 h-6 text-accent" />,
      title: "Rewards Wallet",
      subtitle: "Your eco-points",
      onClick: () => router.push("/rewards"),
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
              <Leaf className="w-5 h-5 text-primary-foreground" />
            </div>
            <div>
              <h1 className="font-bold text-lg text-primary">Smart Waste</h1>
              <p className="text-xs text-muted-foreground">Clean Future</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm">
              <Bell className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="sm">
              <User className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </header>

      {/* Welcome Section */}
      <section className="p-4">
        <Card className="bg-gradient-to-r from-primary/10 to-accent/10 border-primary/20">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center">
                <Leaf className="w-6 h-6 text-primary" />
              </div>
              <div className="flex-1">
                <h2 className="font-semibold text-foreground">Hi {userName}!</h2>
                <p className="text-sm text-muted-foreground">
                  You saved <span className="font-bold text-primary">{co2Saved}kg CO₂</span> this month!
                </p>
              </div>
              <Badge variant="secondary" className="bg-accent text-accent-foreground">
                Eco Hero
              </Badge>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Quick Actions */}
      <section className="p-4">
        <h3 className="font-semibold text-lg mb-4 text-foreground">Quick Actions</h3>
        <div className="grid grid-cols-2 gap-4">
          {quickActions.map((action, index) => (
            <QuickAction
              key={index}
              icon={action.icon}
              title={action.title}
              subtitle={action.subtitle}
              onClick={action.onClick}
              variant={action.variant}
            />
          ))}
        </div>
      </section>

      {/* Stats Overview */}
      <section className="p-4">
        <h3 className="font-semibold text-lg mb-4 text-foreground">This Month</h3>
        <div className="grid grid-cols-3 gap-3">
          <Card>
            <CardContent className="p-3 text-center">
              <div className="text-2xl font-bold text-primary">47</div>
              <div className="text-xs text-muted-foreground">Items Scanned</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-3 text-center">
              <div className="text-2xl font-bold text-accent">89%</div>
              <div className="text-xs text-muted-foreground">Sorted Correctly</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-3 text-center">
              <div className="text-2xl font-bold text-secondary">1,240</div>
              <div className="text-xs text-muted-foreground">Eco Points</div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Recent Activity */}
      <section className="p-4 pb-8">
        <h3 className="font-semibold text-lg mb-4 text-foreground">Recent Activity</h3>
        <div className="space-y-3">
          <Card>
            <CardContent className="p-3">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                  <Camera className="w-4 h-4 text-primary" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium">Plastic bottle scanned</p>
                  <p className="text-xs text-muted-foreground">2 hours ago • +10 points</p>
                </div>
                <Badge variant="outline" className="text-xs">
                  Recyclable
                </Badge>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-3">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-accent/10 rounded-full flex items-center justify-center">
                  <Trophy className="w-4 h-4 text-accent" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium">Reached weekly goal!</p>
                  <p className="text-xs text-muted-foreground">Yesterday • +50 points</p>
                </div>
                <Badge variant="secondary" className="text-xs bg-accent text-accent-foreground">
                  Achievement
                </Badge>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  )
}
