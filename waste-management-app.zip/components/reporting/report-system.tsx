"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { X, MapPin, Camera, AlertTriangle, CheckCircle, Clock, Eye, Trash2, Navigation, Plus } from "lucide-react"

interface Report {
  id: string
  title: string
  description: string
  category: "illegal_dumping" | "overflowing_bins" | "littering" | "hazardous_waste" | "other"
  location: {
    lat: number
    lng: number
    address: string
  }
  photos: string[]
  status: "pending" | "in_progress" | "resolved" | "rejected"
  reportedAt: string
  reportedBy: string
  priority: "low" | "medium" | "high"
  upvotes: number
}

const mockReports: Report[] = [
  {
    id: "1",
    title: "Overflowing garbage bin",
    description: "The bin near the park entrance has been overflowing for 3 days",
    category: "overflowing_bins",
    location: {
      lat: 28.6139,
      lng: 77.209,
      address: "Central Park, Connaught Place",
    },
    photos: ["/overflowing-garbage-bin.png"],
    status: "in_progress",
    reportedAt: "2024-01-15T10:30:00Z",
    reportedBy: "You",
    priority: "high",
    upvotes: 12,
  },
  {
    id: "2",
    title: "Illegal waste dumping",
    description: "Construction waste dumped on the roadside",
    category: "illegal_dumping",
    location: {
      lat: 28.6129,
      lng: 77.2295,
      address: "Sector 15, Near Metro Station",
    },
    photos: ["/construction-waste-dumping.jpg"],
    status: "pending",
    reportedAt: "2024-01-14T15:45:00Z",
    reportedBy: "Anonymous",
    priority: "high",
    upvotes: 8,
  },
  {
    id: "3",
    title: "Littering in public area",
    description: "Plastic bottles and food wrappers scattered around bus stop",
    category: "littering",
    location: {
      lat: 28.6169,
      lng: 77.2065,
      address: "Bus Stop, Janpath Road",
    },
    photos: ["/litter-around-bus-stop.jpg"],
    status: "resolved",
    reportedAt: "2024-01-13T09:15:00Z",
    reportedBy: "Priya S.",
    priority: "medium",
    upvotes: 5,
  },
]

function ReportCard({ report, onUpvote }: { report: Report; onUpvote: (id: string) => void }) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-yellow-100 text-yellow-800"
      case "in_progress":
        return "bg-blue-100 text-blue-800"
      case "resolved":
        return "bg-green-100 text-green-800"
      case "rejected":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "bg-red-100 text-red-800"
      case "medium":
        return "bg-orange-100 text-orange-800"
      case "low":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "illegal_dumping":
        return <AlertTriangle className="w-4 h-4" />
      case "overflowing_bins":
        return <Trash2 className="w-4 h-4" />
      case "littering":
        return <Trash2 className="w-4 h-4" />
      case "hazardous_waste":
        return <AlertTriangle className="w-4 h-4" />
      default:
        return <MapPin className="w-4 h-4" />
    }
  }

  return (
    <Card>
      <CardContent className="p-4">
        <div className="space-y-3">
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2">
                {getCategoryIcon(report.category)}
                <h4 className="font-semibold text-sm">{report.title}</h4>
              </div>
              <p className="text-xs text-muted-foreground mb-2">{report.description}</p>
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <MapPin className="w-3 h-3" />
                {report.location.address}
              </div>
            </div>
            <div className="flex flex-col gap-1">
              <Badge className={`text-xs ${getStatusColor(report.status)}`}>{report.status.replace("_", " ")}</Badge>
              <Badge className={`text-xs ${getPriorityColor(report.priority)}`}>{report.priority}</Badge>
            </div>
          </div>

          {report.photos.length > 0 && (
            <div className="flex gap-2">
              {report.photos.slice(0, 2).map((photo, index) => (
                <img
                  key={index}
                  src={photo || "/placeholder.svg"}
                  alt="Report evidence"
                  className="w-16 h-16 object-cover rounded border"
                />
              ))}
              {report.photos.length > 2 && (
                <div className="w-16 h-16 bg-muted rounded border flex items-center justify-center text-xs">
                  +{report.photos.length - 2}
                </div>
              )}
            </div>
          )}

          <div className="flex items-center justify-between pt-2 border-t">
            <div className="flex items-center gap-4 text-xs text-muted-foreground">
              <span>By {report.reportedBy}</span>
              <span>{new Date(report.reportedAt).toLocaleDateString()}</span>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onUpvote(report.id)}
              className="flex items-center gap-1 text-xs"
            >
              <Eye className="w-3 h-3" />
              {report.upvotes}
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

export function ReportSystem() {
  const [activeTab, setActiveTab] = useState("map")
  const [isReporting, setIsReporting] = useState(false)
  const [selectedLocation, setSelectedLocation] = useState<{ lat: number; lng: number; address: string } | null>(null)
  const [photos, setPhotos] = useState<string[]>([])
  const fileInputRef = useRef<HTMLInputElement>(null)

  const [reportForm, setReportForm] = useState({
    title: "",
    description: "",
    category: "",
  })

  const handleLocationSelect = () => {
    // Simulate getting current location
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((position) => {
        setSelectedLocation({
          lat: position.coords.latitude,
          lng: position.coords.longitude,
          address: "Current Location", // In real app, reverse geocode this
        })
      })
    } else {
      // Fallback location
      setSelectedLocation({
        lat: 28.6139,
        lng: 77.209,
        address: "New Delhi, India",
      })
    }
  }

  const handlePhotoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files
    if (files) {
      // In real app, upload to server and get URLs
      const newPhotos = Array.from(files).map(
        (file) => `/placeholder.svg?height=200&width=300&query=uploaded waste photo`,
      )
      setPhotos([...photos, ...newPhotos])
    }
  }

  const handleSubmitReport = () => {
    if (!selectedLocation || !reportForm.title || !reportForm.category) {
      return
    }

    // Submit report logic
    console.log("Submitting report:", {
      ...reportForm,
      location: selectedLocation,
      photos,
    })

    // Reset form
    setReportForm({ title: "", description: "", category: "" })
    setPhotos([])
    setSelectedLocation(null)
    setIsReporting(false)
  }

  const handleUpvote = (reportId: string) => {
    console.log("Upvoting report:", reportId)
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border p-4">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="sm" onClick={() => window.history.back()}>
            <X className="w-4 h-4" />
          </Button>
          <div className="flex-1">
            <h1 className="font-bold text-lg text-primary">Report Dirty Spots</h1>
            <p className="text-xs text-muted-foreground">Help keep your community clean</p>
          </div>
          <Dialog open={isReporting} onOpenChange={setIsReporting}>
            <DialogTrigger asChild>
              <Button size="sm" className="flex items-center gap-2">
                <Plus className="w-4 h-4" />
                Report
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Report a Dirty Spot</DialogTitle>
                <DialogDescription>Help authorities identify and clean problem areas</DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="title">Title</Label>
                  <Input
                    id="title"
                    placeholder="Brief description of the issue"
                    value={reportForm.title}
                    onChange={(e) => setReportForm({ ...reportForm, title: e.target.value })}
                  />
                </div>

                <div>
                  <Label htmlFor="category">Category</Label>
                  <Select
                    value={reportForm.category}
                    onValueChange={(value) => setReportForm({ ...reportForm, category: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select issue type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="illegal_dumping">Illegal Dumping</SelectItem>
                      <SelectItem value="overflowing_bins">Overflowing Bins</SelectItem>
                      <SelectItem value="littering">Littering</SelectItem>
                      <SelectItem value="hazardous_waste">Hazardous Waste</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    placeholder="Provide more details about the issue"
                    value={reportForm.description}
                    onChange={(e) => setReportForm({ ...reportForm, description: e.target.value })}
                  />
                </div>

                <div>
                  <Label>Location</Label>
                  <div className="flex gap-2">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={handleLocationSelect}
                      className="flex-1 flex items-center gap-2 bg-transparent"
                    >
                      <Navigation className="w-4 h-4" />
                      {selectedLocation ? "Location Selected" : "Use Current Location"}
                    </Button>
                  </div>
                  {selectedLocation && <p className="text-xs text-muted-foreground mt-1">{selectedLocation.address}</p>}
                </div>

                <div>
                  <Label>Photos (Optional)</Label>
                  <div className="space-y-2">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => fileInputRef.current?.click()}
                      className="w-full flex items-center gap-2"
                    >
                      <Camera className="w-4 h-4" />
                      Add Photos
                    </Button>
                    <input
                      ref={fileInputRef}
                      type="file"
                      multiple
                      accept="image/*"
                      onChange={handlePhotoUpload}
                      className="hidden"
                    />
                    {photos.length > 0 && (
                      <div className="flex gap-2 flex-wrap">
                        {photos.map((photo, index) => (
                          <img
                            key={index}
                            src={photo || "/placeholder.svg"}
                            alt="Upload preview"
                            className="w-16 h-16 object-cover rounded border"
                          />
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                <div className="flex gap-2 pt-4">
                  <Button variant="outline" onClick={() => setIsReporting(false)} className="flex-1">
                    Cancel
                  </Button>
                  <Button
                    onClick={handleSubmitReport}
                    className="flex-1"
                    disabled={!selectedLocation || !reportForm.title || !reportForm.category}
                  >
                    Submit Report
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </header>

      {/* Stats Overview */}
      <section className="p-4">
        <div className="grid grid-cols-4 gap-3">
          <Card>
            <CardContent className="p-3 text-center">
              <AlertTriangle className="w-5 h-5 mx-auto mb-1 text-red-500" />
              <div className="text-lg font-bold text-primary">23</div>
              <div className="text-xs text-muted-foreground">Pending</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-3 text-center">
              <Clock className="w-5 h-5 mx-auto mb-1 text-blue-500" />
              <div className="text-lg font-bold text-primary">15</div>
              <div className="text-xs text-muted-foreground">In Progress</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-3 text-center">
              <CheckCircle className="w-5 h-5 mx-auto mb-1 text-green-500" />
              <div className="text-lg font-bold text-primary">87</div>
              <div className="text-xs text-muted-foreground">Resolved</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-3 text-center">
              <Eye className="w-5 h-5 mx-auto mb-1 text-accent" />
              <div className="text-lg font-bold text-primary">125</div>
              <div className="text-xs text-muted-foreground">Total</div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Tabs */}
      <section className="p-4">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2 mb-6">
            <TabsTrigger value="map">Heatmap</TabsTrigger>
            <TabsTrigger value="reports">Recent Reports</TabsTrigger>
          </TabsList>

          <TabsContent value="map" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <MapPin className="w-4 h-4" />
                  Community Reports Heatmap
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="relative">
                  <img
                    src="/city-map-with-red-heat-spots-showing-waste-problem.jpg"
                    alt="Reports heatmap"
                    className="w-full h-64 object-cover rounded border"
                  />
                  <div className="absolute top-2 right-2 bg-white/90 p-2 rounded text-xs">
                    <div className="flex items-center gap-2 mb-1">
                      <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                      <span>High Priority</span>
                    </div>
                    <div className="flex items-center gap-2 mb-1">
                      <div className="w-3 h-3 bg-orange-500 rounded-full"></div>
                      <span>Medium Priority</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                      <span>Low Priority</span>
                    </div>
                  </div>
                </div>
                <p className="text-xs text-muted-foreground mt-2">
                  Red areas indicate high concentration of waste-related issues. Click on markers for details.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Hotspot Areas</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 bg-red-50 rounded border">
                    <div>
                      <h4 className="font-semibold text-sm">Central Park Area</h4>
                      <p className="text-xs text-muted-foreground">8 active reports</p>
                    </div>
                    <Badge className="bg-red-100 text-red-800">High Priority</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-orange-50 rounded border">
                    <div>
                      <h4 className="font-semibold text-sm">Metro Station Vicinity</h4>
                      <p className="text-xs text-muted-foreground">5 active reports</p>
                    </div>
                    <Badge className="bg-orange-100 text-orange-800">Medium Priority</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-green-50 rounded border">
                    <div>
                      <h4 className="font-semibold text-sm">Residential Complex</h4>
                      <p className="text-xs text-muted-foreground">2 active reports</p>
                    </div>
                    <Badge className="bg-green-100 text-green-800">Low Priority</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="reports" className="space-y-3">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-lg text-foreground">Community Reports</h3>
              <Badge variant="outline" className="text-xs">
                Last 7 days
              </Badge>
            </div>
            {mockReports.map((report) => (
              <ReportCard key={report.id} report={report} onUpvote={handleUpvote} />
            ))}
          </TabsContent>
        </Tabs>
      </section>
    </div>
  )
}
